$(".language").mouseenter(function(){
	$(".lang").removeClass("hide");
});
$(".language").mouseleave(function(){
	$(".lang").addClass("hide");
});